import React from 'react';

const PropertyList = () => {
    return (
        <div>
            <h1>This is property list page</h1>
        </div>
    );
};

export default PropertyList;